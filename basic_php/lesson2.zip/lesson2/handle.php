
<?php 
$avatar = $_FILES['avatar'];
$select = $_POST['select'];

var_dump($select);die;