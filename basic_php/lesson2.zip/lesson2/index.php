 <form action="handle.php" method="post" enctype="multipart/form-data">
 <input type="file" name="avatar" >
 <select name="select[]" id="" multiple  >
    <option value="1">one</option>
    <option value="2" >two</option>
    <option value="3" >three</option>
    <option value="4" >four</option>
 </select>
 <button type="submit">submit</button>
 </form>