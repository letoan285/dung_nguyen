<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <title>Document</title>

</head>
<body>
<div class="container">
    <h3 class="text-center">Trang chu</h3>
    <a class="btn btn-info " href="./register.php">Dang ky</a>
    <a class="btn btn-success" href="./login.php">Dang Nhap</a>
</div>
</body>
</html>

<?php 
echo $_COOKIE['name'];

?>