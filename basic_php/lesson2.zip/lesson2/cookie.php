<?php 
setcookie('name', 'nguyen van dung', time()+3);
?>
<a href="./">index</a>