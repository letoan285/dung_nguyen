<?php 
session_start();

$_SESSION['auth']['name'] = 'Dung';
$_SESSION['auth']['email'] = 'Dung@gmail.com';

 //$name = $_SESSION['name'];

//var_dump ($_SESSION['auth']);

//header('location: session.php');