<?php 

    // kieu du lieu
    // string, integer, boolean, float, null, (undefined//js)
    // resource // //

    // 2. string, strlen(), strpos, strrev(), 
    /// 
    // $arr = "       oihroghr     ";  --> trim, ltrim, cat trai, rtrim, cat ben fai, 
    // md5, sha1,

    //$n = sha1('123445');

    //echo $n;
    //ucfirst, ucwords, 
    //strtoupper, strtolower, 
    // 
    //str_replace, (a, b, sentence, );
    //echo 
    // implode, "1,2,3,45,5"; implode(',', "1,2,3,45,5");-->explode , 

    ///

    //II, toan tu, 
    // cong, tru, nhan, chia, binh phuong
    // toan tu toan hoc, +-*/, %.
    // Toan tu so sanh, 
    // toan tu logic, &&, ||, !, or, 
    // Toan tu gan, -=, +=.
    // tang giaam, ++$x, $x++;
    // $x = 3;
    // echo $x++;

    // echo $x;

    // echo 4 + '5';
    // array, 

    // $arr = [1,2,3,'name'=> 'dung', 'age'=>20, 4,7, [33,66]];

    // echo $arr[5][1]; 

    // array methods, pop, push, shift, unshift, forEach, 
    // array_push, array_pop, array_sum(); 
    // count();

    // $arr = [1,2];

    // echo count($arr); array_merge, 
    /*
    $names = ['coc', 'me', 'xoai', 'oi'];

    for($i = 0; $i < count($names); $i++) {
        echo $names[i];
    }
  
    //$name = 'Dung';

    //echo "Hello $name";
    $a = 3;
    function getA($a){
        //global $a;
        //$this->a = $a;
        //$b = $GLOBALS['a'];
        //$GLOBALS['b'] = 8;
        return $a + 7;
    }
   //echo getA(5);

  //$a = (9-5) > 0 ? 'dung' : 'sai'; 

  //$b =4;
  //$a = $b ?? $c ?? 'null'; // coesion operator, 


  //echo $a;
    //include 'header.php';
    //require_once 'header.php';
    //require_once 'header.php';

    //echo "<h1>Body</h2> .";
    //require 'header.php';

    //include 'footer.php';
    //require_once 'footer.php';

    ?>
    <?php 
    $_GET


const myvar= require('..////')


phpinfo()
