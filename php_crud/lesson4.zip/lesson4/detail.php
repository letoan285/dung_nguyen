<?php 


// ve lam bai hien thi chi tiet 1 san pham,
// Xoa 1 san phamm, sau do tro ve trang list(index.php)